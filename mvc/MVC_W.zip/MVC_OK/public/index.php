<?php
// Cargamos el iniciador
require_once '../app/autoload.php';

// Instanciamos la clase controlador
$iniciar = new Core;
