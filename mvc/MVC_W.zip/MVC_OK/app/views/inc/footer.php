

<nav class="footer text-center">
	<p>Framework <?= VERSION_APP ;?></p>
</nav>

		<!-- Optional JavaScript -->
		<!-- jQuery first, then Popper.js, then Bootstrap JS -->
		<script src="<?= RUTA_URL;?>/js/jquery-3.4.1.min.js" "anonymous"></script>
		<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		-->
		<script src="<?= RUTA_URL;?>/js/bootstrap.min.js" "></script>
		<script src="<?= RUTA_URL;?>/js/main.js"></script>
	</body>
</html>